نظام الزعيم - Worker + D1
========================

هذه النسخة ليست Cloudflare Pages Static فقط. يجب نشرها كـ Cloudflare Worker.

الملفات:
public/        واجهة النظام وملفات PWA
src/index.js   Worker + API + الصلاحيات + D1
wrangler.toml  إعداد Worker وStatic Assets

طريقة النشر الموصى بها:
1) ارفع هذا المجلد إلى GitHub في Repository جديد، ويفضل باسم alzaeem-erp.
2) Cloudflare Dashboard > Workers & Pages > Create application > Get started بجوار Import a repository.
3) اختر مستودع GitHub ثم Save and Deploy.
4) افتح Worker الجديد > Settings > Bindings > Add binding > D1 database.
5) Variable name = DB.
6) اختر/أنشئ قاعدة D1 باسم alzaeem-db.
7) احفظ ثم أعد Deploy.

مهم: لا تنشر هذا المشروع من Pages Drag & Drop كـ Static Assets، لأننا نحتاج Worker API وD1.

الدخول الأول:
username: admin
password: 1234

بعد الدخول، غيّر كلمة المرور من الإعدادات.

الصلاحيات:
- المدير: يرى كل النظام ويتحكم في كل شيء.
- الموظف: يرى المبيعات والفواتير الخاصة به فقط، ولا يرى تفاصيل المخزن أو الخزينة أو الموظفين أو التقارير.

البيانات مشتركة بين الأجهزة عن طريق D1. كل فاتورة تسجل الموظف والتاريخ والوقت.
